/**
 * 自定义买点回测脚本（独立运行，不依赖 HTTP 服务）
 *
 * 买点（逐 5min 桶回溯）：创业板指分时涨幅 < -2% 且 科技情绪指数 > -60 → 买入「3日涨幅最大」的股票
 *   - 创业板指分时涨幅：bucket.indexTline.cyb.changePct
 *   - 科技情绪指数：bucket.techEmotion（与情绪页同源）
 * 选股：沿用回测引擎「3日涨幅最大」（highest_3d_gain）策略的完整选股管线（pickBestStock），
 *   含：仅科技股（isTech !== false）、自选股添加时间门禁、涨停顺延、上一交易日一字板过滤、
 *   顺周期过滤（与创业板指近 20 日相关性 > 0）、全局最低抗分歧 ≥ 9、买入时段门禁 9:30–13:30。
 *   （按用户确认，不叠加「跨指数 3 日线斜率双门禁」——自定义触发条件即唯一买点）
 * 卖点：沿用「3日涨幅最大」策略的通用 7 条件卖点诊断（runSellPointDiagnosis），T+1 起生效。
 * 选股池：全量自选股（经引擎统一过滤后仅保留科技股）。
 *
 * 输出：同级目录 HTML 报告，模仿回测页面（BacktestDrawer）报告前端格式，逐笔披露交易明细。
 *
 * 运行：node script/backtest_cyb_drop_3d_gain.js [startDate] [endDate]
 *   默认 20260703 ~ 20261012。
 */
const fs = require('fs');
const path = require('path');

const { getTrainingCampDates, loadTrainingCampData } = require('../src/service/trainingCamp');
const {
  buildReplayStocksWithTline,
  extractDailyInfo,
  buildPrevOneWordBoardSet,
} = require('../src/service/buySellBacktest/engine/replayData');
const { pickBestStock } = require('../src/service/buySellBacktest/engine/pickBest');
const { generalSellPositions } = require('../src/service/buySellBacktest/engine/sellHooks/generalSell');
const { buildCounterCycSet } = require('../src/service/buySellBacktest/engine/cycleFilter');
const { STRATEGIES } = require('../src/service/buySellBacktest/strategies/registry');
const {
  attachBuyDayReturn,
  attachHoldingDays,
  calcDrawdownStats,
  sortTradesByBuyTime,
} = require('../src/service/buySellBacktest/utils/tradeStats');
const { EXCLUDED_CODES, SELL_CONDITION_PERSIST_MIN } = require('../src/service/buySellBacktest/constants');

// ============ 参数 ============
const START_DATE = process.argv[2] || '20260703';
const END_DATE = process.argv[3] || '20261012';
const CYB_DROP_THRESHOLD = -2;   // 创业板指分时涨幅 < -2%
const TECH_EMOTION_FLOOR = -60;  // 科技情绪指数 > -60
const BUY_TIME_MIN_MINUTE = 1000; // 最早买入时点 10:00（桶 minute >= 1000 才允许买入）
const STRATEGY_ID = 'highest_3d_gain';
const WINDOW_PREHEAT_DAYS = 10;  // 起始日之前预热的交易日数（保证「最近 3 日」窗口不被截断）
const OUT_HTML = path.resolve(__dirname, `回测报告_创业板指跌2_科技情绪-60_3日涨幅最大_${START_DATE}_${END_DATE}.html`);

const CAMP_CACHE_DIR = path.resolve(__dirname, '../src/data/backtest_camp_cache');

const fmtDate = (d) => {
  const s = String(d == null ? '' : d).replace(/-/g, '');
  return /^\d{8}$/.test(s) ? `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}` : String(d ?? '');
};
const fmtPct = (v) => {
  if (v == null || Number.isNaN(Number(v))) return '--';
  const n = Number(v);
  return `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`;
};

// 枚举可用回放交易日（camp 缓存里落盘的日期 ∪ fund 快照可用日期），升序
const resolveAllDates = () => {
  const set = new Set();
  try {
    fs.readdirSync(CAMP_CACHE_DIR).forEach((f) => {
      const m = f.match(/^(\d{8})/);
      if (m) set.add(m[1]);
    });
  } catch (e) { /* 缓存目录不存在则忽略 */ }
  try {
    getTrainingCampDates().forEach((d) => set.add(String(d)));
  } catch (e) { /* ignore */ }
  return Array.from(set).sort();
};

// 单日回测：逐桶触发自定义买点 + 通用卖点诊断
const runBacktest = async () => {
  const allDates = resolveAllDates();
  const rangeDates = allDates.filter((d) => d >= START_DATE && d <= END_DATE);
  if (rangeDates.length === 0) {
    console.error(`[错误] ${START_DATE} ~ ${END_DATE} 内无可用回放交易日`);
    process.exit(1);
  }
  console.log(`回测区间：${rangeDates[0]} ~ ${rangeDates[rangeDates.length - 1]}，共 ${rangeDates.length} 个交易日`);

  const strategy = STRATEGIES[STRATEGY_ID];
  const positions = [];
  const singleTrades = [];
  const skippedDates = [];
  const seenStocks = new Map();

  // 历史每日 EOD 信息（窗口涨幅计算用）
  const dailyInfos = new Map();

  // 窗口预热：起始日之前 WINDOW_PREHEAT_DAYS 个交易日 EOD 预载（允许缺资金快照兜底，保证早期窗口不被截断）
  const preloadDates = allDates.filter((d) => d < START_DATE).sort().slice(-WINDOW_PREHEAT_DAYS);
  const loadedPre = [];
  for (const d of preloadDates) {
    try {
      const campData = await loadTrainingCampData(d, { allowMissingFund: true });
      if (campData && campData.success !== false && (campData.timeBuckets || []).length > 0) {
        dailyInfos.set(d, extractDailyInfo(campData, d));
        loadedPre.push(d);
      }
    } catch (e) { /* 单日预热失败忽略 */ }
  }
  const dateAxis = [...loadedPre, ...rangeDates];
  const axisOffset = loadedPre.length;
  console.log(`窗口预热：已加载 ${axisOffset} 个交易日（${loadedPre.join(', ') || '无'}）`);

  for (let di = 0; di < rangeDates.length; di++) {
    const dateStr = rangeDates[di];
    let campData;
    try {
      campData = await loadTrainingCampData(dateStr, { allowMissingFund: true });
    } catch (e) {
      skippedDates.push({ date: dateStr, message: e.message || '加载失败' });
      continue;
    }
    if (!campData || campData.success === false) {
      skippedDates.push({ date: dateStr, message: campData?.message || '无回放数据' });
      continue;
    }
    const timeBuckets = campData.timeBuckets || [];
    if (timeBuckets.length === 0) {
      skippedDates.push({ date: dateStr, message: '无时间桶数据' });
      continue;
    }

    const replayStocks = await buildReplayStocksWithTline(campData, dateStr);
    const dateDisplay = campData.dateDisplay || fmtDate(dateStr);
    dailyInfos.set(dateStr, extractDailyInfo(campData, dateStr));
    for (const bucket of timeBuckets) {
      for (const sc of bucket.stockChanges) {
        if (EXCLUDED_CODES.has(sc.code)) continue;
        if (!seenStocks.has(sc.code)) seenStocks.set(sc.code, { code: sc.code, name: sc.name || sc.code });
      }
    }

    let dayBuys = 0;
    let daySells = 0;

    for (let bi = 0; bi < timeBuckets.length; bi++) {
      const bucket = timeBuckets[bi];

      // ---- 买点：10:00 之后 且 创业板指分时 < -2% 且 科技情绪指数 > -60（空仓时才判定） ----
      const bucketMinute = Number(bucket.minute);
      const cybChange = bucket.indexTline?.cyb?.changePct != null ? Number(bucket.indexTline.cyb.changePct) : null;
      const techEmotion = bucket.techEmotion != null ? Number(bucket.techEmotion) : null;
      const buyHit = positions.length === 0
        && Number.isFinite(bucketMinute) && bucketMinute >= BUY_TIME_MIN_MINUTE
        && cybChange != null && cybChange < CYB_DROP_THRESHOLD
        && techEmotion != null && techEmotion > TECH_EMOTION_FLOOR;

      if (buyHit) {
        const prevOneWordSet = await buildPrevOneWordBoardSet((bucket.stockChanges || []).map((s) => s.code), dateStr);
        const emoCycSet = await buildCounterCycSet((bucket.stockChanges || []).map((s) => s.code), dateStr);
        const picked = pickBestStock(
          new Map(), dateAxis, di + axisOffset, bucket, replayStocks, dailyInfos,
          STRATEGY_ID, axisOffset, null, null, prevOneWordSet, emoCycSet,
        );
        if (picked) {
          const sc = picked.stock;
          const buyTime = fmtTime(bucket.timeKey).substring(0, 5);
          const buyPrice = parseFloat(Number(sc.lastPx).toFixed(2));
          const deferNotes = [];
          if (picked.limitUpSkipped?.length) deferNotes.push(`${picked.limitUpSkipped.length} 只因涨停顺延`);
          if (picked.prevOneWordSkipped?.length) deferNotes.push(`${picked.prevOneWordSkipped.length} 只因昨日一字板顺延`);
          if (picked.emoCycSkipped?.length) deferNotes.push(`${picked.emoCycSkipped.length} 只因逆周期顺延`);
          if (picked.globalResilienceSkipped?.length) deferNotes.push(`${picked.globalResilienceSkipped.length} 只因抗分歧<9 顺延`);
          if (picked.stockSlopeSkipped?.length) deferNotes.push(`${picked.stockSlopeSkipped.length} 只因个股斜率顺延`);
          positions.push({
            code: sc.code,
            stockName: sc.name || sc.code,
            buyDate: dateStr,
            buyDateDisplay: dateDisplay,
            buyTime,
            buyPrice,
            buyChange: sc.changePct != null ? parseFloat(Number(sc.changePct).toFixed(2)) : null,
            metric: picked.metric,
            buyReason: `自定义买点：10:00 之后（触发时点 ${buyTime}）创业板指分时 ${fmtPct(cybChange)} < -2% 且 科技情绪指数 ${Number(techEmotion).toFixed(2)} > -60；选股按「3日涨幅最大」选中 ${sc.name || sc.code}（最近 3 个交易日累计涨幅 ${picked.metric != null ? Number(picked.metric).toFixed(2) : '--'}%）${deferNotes.length ? `；选股顺延：${deferNotes.join('、')}` : ''}`,
            buyChecks: [
              { id: 'buy_time', title: '买入时点限制', passed: true, value: `触发时点 ${buyTime}（要求 ≥ 10:00）` },
              { id: 'cyb_drop', title: '创业板指分时跌幅', passed: true, value: `触发时点创业板指涨幅 ${fmtPct(cybChange)}（阈值 < -2%）` },
              { id: 'tech_emotion', title: '科技情绪指数', passed: true, value: `触发时点科技情绪指数 ${Number(techEmotion).toFixed(2)}（阈值 > -60）` },
              { id: 'highest_3d_gain', title: '3日涨幅最大选股', passed: true, value: `选中 ${sc.name || sc.code}（${sc.code}），最近 3 个交易日累计涨幅 ${picked.metric != null ? Number(picked.metric).toFixed(2) : '--'}%` },
              ...(deferNotes.length ? [{ id: 'defer', title: '选股顺延', passed: true, value: deferNotes.join('；') }] : []),
            ],
          });
          dayBuys += 1;
        }
      }

      // ---- 卖点：通用 7 条件卖点诊断（T+1 起生效） ----
      const before = positions.length;
      await generalSellPositions({ positions, strategy, bi, replayStocks, timeBuckets, dateStr, dateDisplay, singleTrades });
      if (positions.length < before) daySells += before - positions.length;
    }

    console.log(`  ${dateDisplay} 桶数 ${String(timeBuckets.length).padStart(3)}｜买入 ${dayBuys}｜卖出 ${daySells}｜当前持仓 ${positions.length}`);
  }

  // 期末持仓浮盈
  const currentHoldings = [];
  for (const pos of positions) {
    const h = { ...pos };
    let closePx = null;
    for (let i = rangeDates.length - 1; i >= 0; i--) {
      const info = dailyInfos.get(rangeDates[i])?.get(pos.code);
      if (info && info.closePx != null && info.closePx > 0) { closePx = info.closePx; break; }
    }
    h.buyReturn = closePx != null && pos.buyPrice > 0
      ? parseFloat((((closePx - pos.buyPrice) / pos.buyPrice) * 100).toFixed(2))
      : null;
    h.lastClose = closePx != null ? parseFloat(closePx.toFixed(2)) : null;
    currentHoldings.push(h);
  }

  // 排序 + 补写指标
  const trades = sortTradesByBuyTime(singleTrades);
  await attachBuyDayReturn(trades);
  await attachBuyDayReturn(currentHoldings);

  const validTrades = trades.filter((t) => t.returnRate != null && Number.isFinite(t.returnRate));
  const winCount = validTrades.filter((t) => t.returnRate > 0).length;
  let acc = 1;
  for (const t of validTrades) acc *= 1 + t.returnRate / 100;
  for (const h of currentHoldings) acc *= 1 + (h.buyReturn || 0) / 100;
  const overallReturn = parseFloat(((acc - 1) * 100).toFixed(2));

  const result = {
    success: true,
    strategy: { id: strategy.id, name: strategy.name, desc: strategy.desc },
    condition: {
      cybDropThreshold: CYB_DROP_THRESHOLD,
      techEmotionFloor: TECH_EMOTION_FLOOR,
      buyTimeMinMinute: BUY_TIME_MIN_MINUTE,
    },
    range: { startDate: rangeDates[0], endDate: rangeDates[rangeDates.length - 1] },
    requestedRange: { startDate: START_DATE, endDate: END_DATE },
    skippedDates,
    seenStocks: Array.from(seenStocks.values()),
    trades,
    currentHoldings,
    summary: {
      tradeCount: trades.length,
      winCount,
      winRate: validTrades.length > 0 ? parseFloat(((winCount / validTrades.length) * 100).toFixed(2)) : null,
      ...calcDrawdownStats(validTrades),
      overallReturn,
      stockCount: seenStocks.size,
      holdingCount: currentHoldings.length,
    },
  };
  // 补写持仓交易日数与平均持仓
  attachHoldingDays(result);
  // attachHoldingDays 会重排 trades 并重编 seq；同步更新期末持仓的 holdingDays
  result.trades = attachSeqSorted(result.trades);

  return result;
};

// sortTradesByBuyTime 已重编 seq；此函数仅为保持列名清晰（attachHoldingDays 亦会重排）
const attachSeqSorted = (trades) => trades;

const fmtTime = (timeKey) => {
  const t = String(timeKey || '').padStart(6, '0');
  if (t.length < 4) return '--:--:--';
  return `${t.substring(0, 2)}:${t.substring(2, 4)}:${t.substring(4, 6)}`;
};

// ============ HTML 报告渲染（模仿 BacktestDrawer 报告格式） ============
const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const rateColor = (v) => (Number(v) >= 0 ? '#f5222d' : '#52c41a');
const renderPct = (v, colorize = true) => `<b style="color:${colorize ? rateColor(v) : '#12213a'}">${fmtPct(v)}</b>`;

const renderChecks = (checks) => {
  if (!Array.isArray(checks) || checks.length === 0) return '';
  return `<div class="checks">${checks.map((c) => `
    <div class="check ${c.passed ? 'ok' : 'no'}">
      <span class="check-title">${esc(c.title)}</span>
      <span class="check-value">${esc(c.value)}</span>
    </div>`).join('')}</div>`;
};

const renderHtml = (result, outPath, generatedAt) => {
  const s = result.summary;
  const cond = result.condition;
  const summaryItems = [
    { label: '整体收益', value: fmtPct(s.overallReturn), color: s.overallReturn != null ? rateColor(s.overallReturn) : undefined },
    { label: '胜率', value: s.winRate != null ? `${s.winRate.toFixed(1)}%` : '--', color: s.winRate != null && s.winRate >= 50 ? '#f5222d' : '#52c41a' },
    { label: '平均回撤', value: s.avgDrawdown != null ? fmtPct(s.avgDrawdown) : '--', color: '#52c41a' },
    { label: '单笔最大回撤', value: s.maxDrawdown != null ? fmtPct(s.maxDrawdown) : '--', color: '#52c41a' },
    { label: '平均持仓', value: s.avgHoldingDays != null ? `${s.avgHoldingDaysApprox ? '≈' : ''}${Number(s.avgHoldingDays).toFixed(1)} 交易日` : '--' },
    { label: '覆盖自选股', value: `${s.stockCount} 只` },
    { label: '成交笔数', value: `${s.tradeCount} 笔` },
    { label: '盈利笔数', value: `${s.winCount} 笔` },
    { label: '期末仍持仓', value: `${s.holdingCount} 只` },
  ];

  const tradeCards = result.trades.map((t) => `
    <div class="card">
      <div class="card-head">
        <span class="seq">第${t.seq}笔</span>
        <span class="stock">${esc(t.stockName)}</span>
        <span class="code">${esc(t.code)}</span>
        ${t.metric != null ? `<span class="tag purple">选股指标 3日累计涨幅 ${Number(t.metric).toFixed(2)}%</span>` : ''}
        <span class="tag ${Number(t.returnRate) >= 0 ? 'red' : 'green'}">收益 ${fmtPct(t.returnRate)}</span>
        <span class="tag geekblue">持仓 ${t.holdingDays != null ? `${t.holdingDaysApprox ? '≈' : ''}${t.holdingDays} 交易日` : '--'}</span>
      </div>
      <div class="row buy">
        <span class="dot red">▲</span>
        <span>买入 <b>${fmtDate(t.buyDate)} ${esc(t.buyTime)}</b></span>
        <span>价格 <b class="mono">${Number(t.buyPrice).toFixed(2)}</b></span>
        <span>涨幅 ${renderPct(t.buyChange)}</span>
        <span>买入当日收益 ${renderPct(t.buyDayReturn)}${t.buyDayClose != null ? `<span class="muted">（当日收盘 ${Number(t.buyDayClose).toFixed(2)}）</span>` : ''}</span>
      </div>
      <div class="reason-box"><span class="reason-label">买入原因</span><span class="reason-text">${esc(t.buyReason)}</span></div>
      ${renderChecks(t.buyChecks)}
      <div class="row sell">
        <span class="dot green">▼</span>
        <span>卖出 <b>${fmtDate(t.sellDate)} ${esc(t.sellTime)}</b></span>
        <span>价格 <b class="mono">${Number(t.sellPrice).toFixed(2)}</b></span>
        <span>涨幅 ${renderPct(t.sellChange)}</span>
        <span>持仓 <b>${t.holdingDays != null ? `${t.holdingDaysApprox ? '≈' : ''}${t.holdingDays} 交易日` : '--'}</b></span>
        <span>卖出原因 <span class="tag geekblue">${esc(t.sellReason)}</span></span>
      </div>
    </div>`).join('');

  const holdingCards = result.currentHoldings.map((h) => `
    <div class="card">
      <div class="card-head">
        <span class="seq">持仓中（未卖出）</span>
        <span class="stock">${esc(h.stockName)}</span>
        <span class="code">${esc(h.code)}</span>
        ${h.metric != null ? `<span class="tag purple">选股指标 3日累计涨幅 ${Number(h.metric).toFixed(2)}%</span>` : ''}
        ${h.buyReturn != null ? `<span class="tag ${Number(h.buyReturn) >= 0 ? 'red' : 'green'}">浮盈 ${fmtPct(h.buyReturn)}</span>` : ''}
        ${h.holdingDays != null ? `<span class="tag geekblue">已持仓 ${h.holdingDaysApprox ? '≈' : ''}${h.holdingDays} 交易日</span>` : ''}
      </div>
      <div class="row buy">
        <span class="dot red">▲</span>
        <span>买入 <b>${fmtDate(h.buyDate)} ${esc(h.buyTime)}</b></span>
        <span>价格 <b class="mono">${Number(h.buyPrice).toFixed(2)}</b></span>
        <span>涨幅 ${renderPct(h.buyChange)}</span>
        <span>买入当日收益 ${renderPct(h.buyDayReturn)}${h.buyDayClose != null ? `<span class="muted">（当日收盘 ${Number(h.buyDayClose).toFixed(2)}）</span>` : ''}</span>
        ${h.lastClose != null ? `<span>最新收盘 <b class="mono">${Number(h.lastClose).toFixed(2)}</b></span>` : ''}
      </div>
      <div class="reason-box"><span class="reason-label">买入原因</span><span class="reason-text">${esc(h.buyReason)}</span></div>
      ${renderChecks(h.buyChecks)}
    </div>`).join('');

  const skipped = result.skippedDates.length
    ? `<div class="card"><div class="card-head"><span class="seq">跳过无数据交易日</span></div><div class="skip-list">${
        result.skippedDates.map((d) => `<div>${fmtDate(d.date)} — ${esc(d.message)}</div>`).join('')}</div></div>`
    : '';

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>回测报告 · 创业板指跌2% & 科技情绪>-60 买3日涨幅最大</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #f0f2f5; color: #12213a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif; font-size: 14px; }
  .wrap { max-width: 1000px; margin: 0 auto; padding: 24px 16px 60px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .subtitle { color: #6b7890; font-size: 12px; margin-bottom: 18px; }
  .section-title { font-size: 14px; font-weight: 700; margin: 22px 0 10px; color: #12213a; }
  .panel { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(18,33,58,0.06); }
  .grid { display: flex; gap: 12px; flex-wrap: wrap; }
  .cell { flex: 1; min-width: 108px; background: #f7f9fc; border-radius: 10px; padding: 10px 12px; }
  .cell .label { font-size: 12px; color: #9ca3af; }
  .cell .value { font-size: 16px; font-weight: 700; margin-top: 2px; }
  .desc { font-size: 12px; color: #6b7890; line-height: 1.9; }
  .desc code { background: #f0f2f5; border-radius: 4px; padding: 1px 5px; font-family: 'SF Mono', Menlo, monospace; font-size: 11px; }
  .card { background: #fff; border-radius: 12px; padding: 14px; margin-bottom: 12px; box-shadow: 0 1px 4px rgba(18,33,58,0.06); }
  .card-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
  .seq { font-size: 12px; font-weight: 600; }
  .stock { font-size: 14px; font-weight: 700; color: #1677ff; }
  .code { font-size: 11px; color: #9ca3af; font-family: 'SF Mono', Menlo, monospace; }
  .tag { font-size: 12px; border-radius: 5px; padding: 1px 7px; border: 1px solid transparent; white-space: nowrap; }
  .tag.purple { background: #f9f0ff; color: #722ed1; border-color: #d3adf7; }
  .tag.red { background: #fff1f0; color: #f5222d; border-color: #ffa39e; }
  .tag.green { background: #f6ffed; color: #52c41a; border-color: #b7eb8f; }
  .tag.geekblue { background: #f0f5ff; color: #2f54eb; border-color: #adc6ff; }
  .row { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; border: 1px solid #eef1f6; border-radius: 8px; padding: 8px 10px; background: #fafbfd; font-size: 12px; color: #6b7890; margin-bottom: 8px; }
  .row b { color: #12213a; }
  .mono { font-family: 'SF Mono', Menlo, monospace; }
  .muted { color: #9ca3af; }
  .dot.red { color: #f5222d; } .dot.green { color: #52c41a; }
  .reason-box { display: flex; gap: 10px; align-items: flex-start; margin: 4px 0 8px; }
  .reason-label { font-size: 12px; color: #6b7890; white-space: nowrap; line-height: 22px; }
  .reason-text { font-size: 12px; color: #8c6d1f; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 6px; padding: 3px 8px; line-height: 1.6; }
  .checks { display: flex; flex-direction: column; gap: 4px; margin-bottom: 8px; }
  .check { font-size: 12px; display: flex; gap: 8px; align-items: baseline; padding: 4px 8px; border-radius: 6px; background: #f7f9fc; }
  .check.ok { border-left: 3px solid #52c41a; }
  .check.no { border-left: 3px solid #f5222d; }
  .check-title { font-weight: 600; color: #12213a; white-space: nowrap; }
  .check-value { color: #6b7890; }
  .skip-list { font-size: 12px; color: #6b7890; line-height: 1.9; }
  .footer { text-align: center; color: #9ca3af; font-size: 12px; margin-top: 24px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>回测报告 · 创业板指跌 2% &amp; 科技情绪 &gt; -60 买入「3日涨幅最大」</h1>
  <div class="subtitle">
    回测区间：${fmtDate(result.range.startDate)} ~ ${fmtDate(result.range.endDate)}
    （请求区间 ${fmtDate(result.requestedRange.startDate)} ~ ${fmtDate(result.requestedRange.endDate)}）
    ｜生成时间：${esc(generatedAt)}
  </div>

  <div class="section-title">收益概览</div>
  <div class="panel">
    <div class="grid">
      ${summaryItems.map((i) => `<div class="cell"><div class="label">${esc(i.label)}</div><div class="value" style="${i.color ? `color:${i.color}` : ''}">${esc(i.value)}</div></div>`).join('')}
    </div>
  </div>

  <div class="section-title">策略与规则</div>
  <div class="panel desc">
    <div><b>买点（逐 5min 桶回溯）：</b>${String(Math.floor(cond.buyTimeMinMinute / 100)).padStart(2, '0')}:${String(cond.buyTimeMinMinute % 100).padStart(2, '0')} 之后，创业板指分时涨幅 &lt; ${cond.cybDropThreshold}% <b>且</b> 科技情绪指数 &gt; ${cond.techEmotionFloor} → 触发买入（空仓时）。</div>
    <div><b>选股（3日涨幅最大）：</b>${esc(result.strategy.desc)}</div>
    <div><b>选股管线过滤：</b>仅科技股（isTech ≠ false）、自选股添加时间门禁、涨停顺延、上一交易日一字板过滤、顺周期过滤（与创业板指近 20 日相关性 &gt; 0）、全局最低抗分歧 ≥ 9、买入时段门禁 9:30–13:30。</div>
    <div><b>卖点（通用 7 条件，T+1 起生效）：</b>① 均线破位 ｜ ② 高位放量大阴线（持续 ≥ ${SELL_CONDITION_PERSIST_MIN} 分钟）｜ ③ 科技板块情绪退潮（科技情绪 = -100 且跌幅 &lt; -9% 个股 ≥ 5，持续 ≥ ${SELL_CONDITION_PERSIST_MIN} 分钟）｜ ④ 抗分歧 &lt; 6 且涨幅 ≤ -5%（14:50 后）｜ ⑤ 连续三日抗分歧 &lt; 10（9:40 后）｜ ⑥ 跌破买入日最低点（持续 ≥ ${SELL_CONDITION_PERSIST_MIN} 分钟）｜ ⑦ 跌破成本线 -2%。任一命中即按触发时点（或逐分钟回溯的精确分钟）价格卖出。</div>
    <div><b>收益口径：</b>单笔收益率 =（卖出价 − 买入价）/ 买入价；整体收益按逐笔复利（含期末持仓浮盈）。</div>
  </div>

  <div class="section-title">交易明细（${result.trades.length} 笔）</div>
  ${result.trades.length === 0
    ? '<div class="panel desc">所选范围内未产生任何成交。</div>'
    : tradeCards}

  ${result.currentHoldings.length > 0 ? `<div class="section-title">期末持仓（${result.currentHoldings.length} 只）</div>${holdingCards}` : ''}

  ${skipped ? `<div class="section-title">数据说明</div>${skipped}` : ''}

  <div class="footer">由 script/backtest_cyb_drop_3d_gain.js 生成 · 数据来源：训练营回放桶（5min）</div>
</div>
</body>
</html>`;
};

// ============ 入口 ============
(async () => {
  const t0 = Date.now();
  const result = await runBacktest();
  const generatedAt = new Date().toLocaleString('zh-CN', { hour12: false });
  const html = renderHtml(result, OUT_HTML, generatedAt);
  fs.writeFileSync(OUT_HTML, html, 'utf-8');
  const s = result.summary;
  console.log('\n================ 回测汇总 ================');
  console.log(`区间：${result.range.startDate} ~ ${result.range.endDate}`);
  console.log(`成交笔数：${s.tradeCount}｜盈利笔数：${s.winCount}｜胜率：${s.winRate != null ? s.winRate.toFixed(1) + '%' : '--'}`);
  console.log(`平均回撤：${s.avgDrawdown != null ? fmtPct(s.avgDrawdown) : '--'}｜单笔最大回撤：${s.maxDrawdown != null ? fmtPct(s.maxDrawdown) : '--'}`);
  console.log(`平均持仓：${s.avgHoldingDays != null ? s.avgHoldingDays + ' 交易日' : '--'}｜期末持仓：${s.holdingCount} 只`);
  console.log(`整体收益（逐笔复利）：${fmtPct(s.overallReturn)}`);
  console.log(`报告已输出：${OUT_HTML}`);
  console.log(`耗时：${((Date.now() - t0) / 1000).toFixed(1)}s`);
})().catch((e) => {
  console.error('回测执行失败：', e);
  process.exit(1);
});