// 主线板块回溯脚本（临时）
// 用途：回溯 2026-07-28 ~ 2026-10-09 每个交易日的主线板块，按「龙头高度 / 涨停家数总量 / 连续上榜天数」
//       三维度加权评分，识别每日主线，聚合成「主线周期」，并给出周期持续时间与板块内龙头/龙二/龙三。
// 数据来源：server/src/data/lianbanSnapshot/*.json（每日连板复盘快照，含 themes[].board 与 stocks[].lianbanCount）
// 产出：server/script/mainline_sectors_0728_1009.html
// 运行：node script/mainline-sectors.js   （可用 START=YYYYMMDD END=YYYYMMDD 覆盖区间）
'use strict';

const fs = require('fs');
const path = require('path');

const DIR = path.join(__dirname, '../src/data/lianbanSnapshot');
const OUT = path.join(__dirname, 'mainline_sectors_0728_1009.html');

const START = process.env.START || '20260728';
const END = process.env.END || '20261009';

// 每日板块主线评分权重（三维度加权）
const W = { height: 3, count: 1, streak: 2 };
// 板块内个股排序权重（用于选出龙头/龙二/龙三）
const SW = { height: 3, days: 2, leader: 2 };

// 「其他」为杂项汇总桶、「并购重组」按需求排除，均不视为主线板块；对明显同义的板块名做归一
const EXCLUDE = new Set(['其他', '并购重组']);
// 仅保留持续时间 >= MIN_DAYS 个交易日的主线周期（默认剔除只持续 1 天的短周期）
const MIN_DAYS = 2;

// 个股筛选默认参数（报告页内可手动调整；两条件需同时满足）
const GAIN_DAYS = Number(process.env.GAIN_DAYS || 10); // 条件①：n 日
const GAIN_PCT = Number(process.env.GAIN_PCT || 70);   // 条件①：涨幅阈值 %（>=）
const BOARD_MIN = Number(process.env.BOARD_MIN || 3);  // 条件②：历史最高连板阈值（>=）
const ALIAS = { 国产芯片: '芯片', 机器人: '机器人概念', 'AI大模型/智能体': 'AI应用' };

const PALETTE = [
  '#1677ff', '#722ed1', '#fa8c16', '#13c2c2', '#eb2f96', '#52c41a',
  '#2f54eb', '#faad14', '#08979c', '#c41d7f', '#a0d911', '#f5222d',
];

const norm = (b) => {
  const x = String(b || '').replace(/\([^)]*\)/g, '').trim();
  return ALIAS[x] || x;
};

// ---------- 1. 载入区间内每日快照 ----------
const dates = fs.readdirSync(DIR)
  .filter((f) => /^\d{8}\.json$/.test(f))
  .map((f) => f.slice(0, 8))
  .filter((d) => d >= START && d <= END)
  .sort();

if (dates.length === 0) {
  console.error(`区间 ${START}~${END} 内无快照数据`);
  process.exit(1);
}

// ---------- 2. 逐日计算板块加权分（含连续上榜天数） ----------
const streak = {}; // 板块 -> 截至当日的连续上榜天数
const dayData = []; // [{ date, board, score, sectors: { board: {height,count,stocks} }, rank }]

for (const d of dates) {
  const j = JSON.parse(fs.readFileSync(path.join(DIR, `${d}.json`), 'utf8'));
  const sectors = {};
  for (const t of (j.themes || [])) {
    const b = norm(t.board);
    if (!b || EXCLUDE.has(b)) continue;
    const s = sectors[b] || (sectors[b] = { height: 0, count: 0, stocks: [] });
    s.count += t.count || (t.stocks || []).length;
    for (const st of (t.stocks || [])) {
      s.height = Math.max(s.height, st.lianbanCount || 0);
      s.stocks.push({
        code: st.code,
        name: st.name,
        lianbanCount: st.lianbanCount || 0,
        lianbanText: st.lianbanText || '',
        leader: !!st.leader,
        sealTime: st.sealTime || '',
        concept: st.concept || '',
      });
    }
  }
  // 更新连续上榜天数（当日缺席的板块清零）
  for (const b of Object.keys(streak)) if (!sectors[b]) delete streak[b];
  for (const b of Object.keys(sectors)) streak[b] = (streak[b] || 0) + 1;

  // 三维度加权评分
  const rank = Object.keys(sectors).map((b) => {
    const s = sectors[b];
    const score = W.height * s.height + W.count * s.count + W.streak * streak[b];
    return { board: b, score, height: s.height, count: s.count, streak: streak[b] };
  }).sort((a, b) => b.score - a.score || b.count - a.count || (a.board < b.board ? -1 : 1));

  if (rank.length === 0) continue;
  dayData.push({ date: d, sectors, rank });
}

// ---------- 3. 每日主线 = 当日评分最高板块；孤立单日抖动并入相邻同板块 ----------
let leaders = dayData.map((x) => x.rank[0].board);
for (let i = 1; i < leaders.length - 1; i++) {
  if (leaders[i - 1] === leaders[i + 1] && leaders[i] !== leaders[i - 1]) leaders[i] = leaders[i - 1];
}

// ---------- 4. 聚合为主线周期（连续的相同主线为一段），并剔除只持续 1 天的短周期 ----------
let segments = [];
{
  let cur = null;
  dayData.forEach((x, i) => {
    const board = leaders[i];
    if (cur && cur.board === board) {
      cur.end = x.date;
      cur.dayCount += 1;
    } else {
      cur = { board, start: x.date, end: x.date, dayCount: 1 };
      segments.push(cur);
    }
  });
}
segments = segments.filter((s) => s.dayCount >= MIN_DAYS);

// ---------- 5. 计算每段指标与板块内龙头/龙二/龙三 ----------
const ROLE = ['龙头', '龙二', '龙三'];
for (const seg of segments) {
  const days = dayData.filter((x, i) => leaders[i] === seg.board && x.date >= seg.start && x.date <= seg.end);
  seg.dayCount = days.length;
  seg.avgScore = Math.round(days.reduce((a, x) => a + x.rank.find((r) => r.board === seg.board).score, 0) / days.length);
  seg.maxHeight = Math.max(...days.map((x) => x.rank.find((r) => r.board === seg.board).height));
  seg.totalCount = days.reduce((a, x) => a + x.rank.find((r) => r.board === seg.board).count, 0);
  seg.maxStreak = Math.max(...days.map((x) => x.rank.find((r) => r.board === seg.board).streak));

  // 汇总该板块在本段内的个股表现
  const agg = new Map();
  for (const x of days) {
    const s = x.sectors[seg.board];
    if (!s) continue;
    for (const st of s.stocks) {
      const a = agg.get(st.code) || {
        code: st.code, name: st.name, maxHeight: 0, days: 0, leaderDays: 0,
        firstDate: x.date, concept: st.concept, bestText: '', sealTime: '',
      };
      a.days += 1;
      a.leaderDays += st.leader ? 1 : 0;
      if (st.lianbanCount > a.maxHeight) {
        a.maxHeight = st.lianbanCount;
        a.bestText = st.lianbanText;
        a.sealTime = st.sealTime;
        a.concept = st.concept || a.concept;
      } else if (!a.bestText) {
        a.bestText = st.lianbanText;
      }
      agg.set(st.code, a);
    }
  }
  const stocks = [...agg.values()].map((a) => ({
    ...a,
    score: SW.height * a.maxHeight + SW.days * a.days + SW.leader * a.leaderDays,
  })).sort((a, b) => b.score - a.score || a.maxHeight - b.maxHeight || a.firstDate.localeCompare(b.firstDate) || (a.code < b.code ? -1 : 1));

  seg.stocks = stocks;
  seg.top = stocks.slice(0, 3).map((s, i) => ({ ...s, role: ROLE[i] || '' }));
}

// 同段次强板块（用于参考）
for (const seg of segments) {
  const days = dayData.filter((x, i) => leaders[i] === seg.board && x.date >= seg.start && x.date <= seg.end);
  const total = {};
  for (const x of days) for (const r of x.rank) if (r.board !== seg.board) total[r.board] = (total[r.board] || 0) + r.score;
  const second = Object.entries(total).sort((a, b) => b[1] - a[1])[0];
  seg.secondBoard = second ? second[0] : '-';
}

// ---------- 5b. 个股筛选数据：日K收盘序列（算 n 日涨幅）+ 历史最高连板 ----------
const KLINE_DIR = path.join(__dirname, '../src/data/kline_cache');

// 6 位代码 -> kline_cache 文件名
const klineIndex = {};
for (const f of fs.readdirSync(KLINE_DIR)) {
  const m = f.match(/^(sh|sz|bj)(\d{6})\.json$/);
  if (m) klineIndex[m[2]] = f;
}

// 历史最高连板 + 名称：扫描 lianbanSnapshot 全部快照（含区间之外，满足「曾有过」语义）
const maxBoardMap = {};
const nameMap = {};
for (const f of fs.readdirSync(DIR)) {
  if (!/^\d{8}\.json$/.test(f)) continue;
  let j;
  try { j = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch (e) { continue; }
  for (const t of (j.themes || [])) for (const st of (t.stocks || [])) {
    nameMap[st.code] = st.name;
    const lb = st.lianbanCount || 0;
    if (!maxBoardMap[st.code] || lb > maxBoardMap[st.code]) maxBoardMap[st.code] = lb;
  }
}

// 区间内涉及的全部个股
const allCodes = [...new Set(segments.flatMap((s) => s.stocks.map((x) => x.code)))];

// 读取日K（截断至 END），求并集交易日历
const barsByCode = {};
const dateSet = new Set();
for (const code of allCodes) {
  const f = klineIndex[code];
  if (!f) { barsByCode[code] = null; continue; }
  let j;
  try { j = JSON.parse(fs.readFileSync(path.join(KLINE_DIR, f), 'utf8')); } catch (e) { barsByCode[code] = null; continue; }
  const bars = {};
  for (const b of (j.kline || [])) {
    const ds = String(b.trade_date);
    if (ds > END || !(b.close_px > 0)) continue;
    bars[ds] = b.close_px;
    dateSet.add(ds);
  }
  barsByCode[code] = bars;
}

// 交易日历：并集升序；从「7.28 前 60 个交易日」起截断（为任意 n 回看留足余量）
const cal = [...dateSet].sort();
const i728 = cal.indexOf(START);
const AXIS = cal.slice(Math.max(0, i728 < 0 ? cal.length - 60 : i728 - 60));
const EVAL_START = i728 >= 10 ? cal[i728 - 10] : cal[0]; // 条件①统计起点：7.28 前 10 个交易日

// 收盘价序列对齐到 AXIS
const stocksMeta = {};
for (const code of allCodes) {
  const bars = barsByCode[code];
  stocksMeta[code] = {
    nm: nameMap[code] || code,
    mb: maxBoardMap[code] || 0,
    cl: AXIS.map((d) => (bars && bars[d] != null) ? Math.round(bars[d] * 100) / 100 : null),
  };
}

// 注入前端的数据
const META = {
  axis: AXIS,
  evalStart: EVAL_START,
  end: END,
  defaults: { n: GAIN_DAYS, xx: GAIN_PCT, m: BOARD_MIN },
  stocks: stocksMeta,
  segments: segments.map((s) => ({ codes: s.stocks.map((x) => x.code), top: s.top.map((t) => t.code) })),
};

// ---------- 6. 输出 HTML ----------
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));
const fmtDate = (d) => `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`;

// 前端脚本：按输入框的 n / xx / 连板 阈值实时筛选个股（① 历史 n 日涨幅 >= xx%；② 历史最高连板 >= n）
const clientJs = `
(function () {
  var META = ${JSON.stringify(META)};
  var ROLE = ['龙头', '龙二', '龙三'];
  var cache = {};
  function series(code) {
    var s = META.stocks[code]; if (!s) return [];
    var out = [];
    for (var i = 0; i < META.axis.length; i++) if (s.cl[i] != null) out.push([META.axis[i], s.cl[i]]);
    return out;
  }
  function maxGain(code, n) {
    var key = code + '_' + n;
    if (cache[key] !== undefined) return cache[key];
    var ser = series(code), best = null;
    for (var i = 0; i < ser.length; i++) {
      var d = ser[i][0];
      if (d < META.evalStart || d > META.end) continue;
      if (i < n) continue;
      var g = (ser[i][1] / ser[i - n][1] - 1) * 100;
      if (!best || g > best.g) best = { g: g, d: d };
    }
    cache[key] = best; return best;
  }
  function num(id, def) { var v = parseFloat(document.getElementById(id).value); return isNaN(v) ? def : v; }
  function render() {
    var n = Math.max(1, Math.round(num('in-n', META.defaults.n)));
    var xx = num('in-xx', META.defaults.xx);
    var m = Math.max(1, Math.round(num('in-m', META.defaults.m)));
    var total = 0;
    var boxes = document.querySelectorAll('[data-seg]');
    for (var bi = 0; bi < boxes.length; bi++) {
      var el = boxes[bi], seg = META.segments[parseInt(el.getAttribute('data-seg'), 10)], rows = [];
      for (var ci = 0; ci < seg.codes.length; ci++) {
        var code = seg.codes[ci], st = META.stocks[code] || {}, mb = st.mb || 0;
        if (mb < m) continue;
        var g = maxGain(code, n);
        if (!g || g.g < xx) continue;
        var ri = seg.top.indexOf(code);
        rows.push({ code: code, nm: st.nm, g: g, mb: mb, role: ri >= 0 ? ROLE[ri] : '' });
      }
      rows.sort(function (a, b) { return b.g.g - a.g.g; });
      total += rows.length;
      var html = '';
      if (!rows.length) { html = '<div class="f-empty">无符合条件个股</div>'; }
      for (var r = 0; r < rows.length; r++) {
        var it = rows[r];
        html += '<div class="f-item">'
          + (it.role ? '<span class="role role-' + it.role + '">' + it.role + '</span>' : '')
          + '<span class="stock-name">' + it.nm + '</span>'
          + '<span class="stock-code">' + it.code + '</span>'
          + '<span class="tag">历史最高 ' + it.mb + ' 连板</span>'
          + '<span class="tag up">' + n + '日最大涨幅 ' + it.g.g.toFixed(1) + '%（' + it.g.d.slice(4, 6) + '-' + it.g.d.slice(6, 8) + '）</span>'
          + '</div>';
      }
      el.innerHTML = html;
    }
    document.getElementById('f-total').textContent = total;
  }
  ['in-n', 'in-xx', 'in-m'].forEach(function (id) { document.getElementById(id).addEventListener('input', render); });
  render();
})();
`;

const timelineHtml = segments.map((s, i) => {
  const color = PALETTE[i % PALETTE.length];
  const title = `${s.board}｜${fmtDate(s.start)} ~ ${fmtDate(s.end)}｜持续 ${s.dayCount} 个交易日`;
  return `<div class="tl-seg" style="flex:${s.dayCount} 1 0;background:${color}" title="${esc(title)}">`
    + `<span class="tl-name">${esc(s.board)}</span><span class="tl-days">${s.dayCount}日</span></div>`;
}).join('');

const cardsHtml = segments.map((s, i) => {
  const color = PALETTE[i % PALETTE.length];
  const topRows = s.top.map((t) => `
      <div class="top-item">
        <span class="role role-${t.role}">${esc(t.role)}</span>
        <span class="stock-name">${esc(t.name)}</span>
        <span class="stock-code">${esc(t.code)}</span>
        <span class="tag">最高 ${t.maxHeight} 连板</span>
        <span class="tag">上榜 ${t.days} 天</span>
        <span class="tag">领涨 ${t.leaderDays} 次</span>
        <span class="stock-concept">${esc(t.concept || t.bestText || '')}</span>
      </div>`).join('');
  const allRows = s.stocks.map((t, idx) => `
        <tr><td>${idx + 1}</td><td>${esc(t.name)}</td><td>${esc(t.code)}</td><td>${t.maxHeight}</td><td>${t.days}</td><td>${t.leaderDays}</td><td class="c">${esc(t.concept || t.bestText || '')}</td></tr>`).join('');
  return `
  <div class="card">
    <div class="card-head" style="border-left-color:${color}">
      <div class="card-title">
        <span class="board-dot" style="background:${color}"></span>${esc(s.board)}
        <span class="dur">持续 ${s.dayCount} 个交易日</span>
      </div>
      <div class="card-sub">${fmtDate(s.start)} ~ ${fmtDate(s.end)}　·　同期次强：${esc(s.secondBoard)}</div>
    </div>
    <div class="metrics">
      <div class="metric"><span class="m-label">最高龙头高度</span><span class="m-value">${s.maxHeight} 连板</span></div>
      <div class="metric"><span class="m-label">涨停家数合计</span><span class="m-value">${s.totalCount}</span></div>
      <div class="metric"><span class="m-label">最长连续上榜</span><span class="m-value">${s.maxStreak} 天</span></div>
      <div class="metric"><span class="m-label">主线均分</span><span class="m-value">${s.avgScore}</span></div>
    </div>
    <div class="top-list">${topRows}</div>
    <div class="f-box">
      <div class="f-title">符合筛选条件个股（① 且 ②）</div>
      <div class="f-list" data-seg="${i}"><div class="f-empty">计算中…</div></div>
    </div>
    <details class="all"><summary>全部上榜个股（${s.stocks.length}）</summary>
      <table class="all-table">
        <thead><tr><th>#</th><th>名称</th><th>代码</th><th>最高连板</th><th>上榜天数</th><th>领涨次数</th><th>概念</th></tr></thead>
        <tbody>${allRows}</tbody>
      </table>
    </details>
  </div>`;
}).join('');

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>主线板块回溯 ${fmtDate(dates[0])} ~ ${fmtDate(dates[dates.length - 1])}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#f5f5f5; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif; padding:24px; color:#262626; }
  .wrap { max-width:1280px; margin:0 auto; }
  .page-header h1 { font-size:22px; }
  .page-header .sub { font-size:13px; color:#8c8c8c; margin-top:6px; line-height:20px; }
  .formula { display:inline-block; background:#fff; border:1px solid #eee; border-radius:6px; padding:2px 8px; margin:0 2px; color:#1677ff; }
  .tl-card, .card { background:#fff; border-radius:8px; box-shadow:0 1px 2px rgba(0,0,0,0.06); }
  .tl-card { padding:18px 20px; margin:16px 0 20px; }
  .tl-head { font-size:15px; font-weight:600; margin-bottom:12px; }
  .timeline { display:flex; gap:2px; height:46px; border-radius:6px; overflow:hidden; }
  .tl-seg { display:flex; flex-direction:column; align-items:center; justify-content:center; color:#fff; min-width:26px; overflow:hidden; transition:filter .15s; }
  .tl-seg:hover { filter:brightness(1.12); }
  .tl-name { font-size:12px; font-weight:600; white-space:nowrap; }
  .tl-days { font-size:10px; opacity:.85; }
  .seg-head { font-size:15px; font-weight:600; margin-bottom:4px; display:flex; align-items:center; gap:6px; }
  .seg-head::before { content:''; width:3px; height:14px; background:#1677ff; border-radius:2px; }
  .cards { display:flex; flex-direction:column; gap:16px; }
  .card { padding:16px 20px; }
  .card-head { padding-left:12px; border-left:4px solid #1677ff; margin-bottom:12px; }
  .card-title { font-size:17px; font-weight:700; display:flex; align-items:center; gap:8px; }
  .board-dot { width:10px; height:10px; border-radius:50%; display:inline-block; }
  .dur { font-size:12px; font-weight:500; color:#1677ff; background:#e6f4ff; border:1px solid #bae0ff; border-radius:10px; padding:1px 10px; }
  .card-sub { font-size:12px; color:#8c8c8c; margin-top:6px; }
  .metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:14px; }
  .metric { background:#fafafa; border:1px solid #f0f0f0; border-radius:6px; padding:10px 12px; display:flex; flex-direction:column; gap:4px; }
  .m-label { font-size:12px; color:#8c8c8c; }
  .m-value { font-size:18px; font-weight:700; color:#f5222d; }
  .top-list { display:flex; flex-direction:column; gap:8px; }
  .top-item { display:flex; align-items:center; gap:8px; flex-wrap:wrap; background:#fafafa; border-radius:6px; padding:8px 12px; }
  .role { font-size:12px; font-weight:700; border-radius:4px; padding:1px 8px; color:#fff; }
  .role-龙头 { background:#f5222d; } .role-龙二 { background:#fa8c16; } .role-龙三 { background:#faad14; }
  .stock-name { font-size:15px; font-weight:600; }
  .stock-code { font-size:12px; color:#8c8c8c; }
  .tag { font-size:12px; color:#595959; background:#fff; border:1px solid #eee; border-radius:4px; padding:1px 6px; }
  .stock-concept { font-size:12px; color:#8c8c8c; margin-left:auto; }
  .filters { display:flex; flex-wrap:wrap; align-items:center; gap:8px; background:#fff; border-radius:8px; box-shadow:0 1px 2px rgba(0,0,0,0.06); padding:12px 16px; margin:0 0 16px; font-size:13px; }
  .filters input { width:64px; border:1px solid #d9d9d9; border-radius:6px; padding:3px 6px; font-size:13px; text-align:center; }
  .filters .sep { color:#bfbfbf; }
  .f-hit { margin-left:auto; color:#8c8c8c; }
  .f-hit b { color:#f5222d; font-size:16px; }
  .f-box { margin-top:12px; border-top:1px dashed #f0f0f0; padding-top:10px; }
  .f-title { font-size:13px; font-weight:600; color:#262626; margin-bottom:8px; }
  .f-list { display:flex; flex-direction:column; gap:6px; }
  .f-item { display:flex; align-items:center; gap:8px; flex-wrap:wrap; background:#fff7e6; border:1px solid #ffe7ba; border-radius:6px; padding:7px 12px; }
  .f-empty { font-size:13px; color:#bfbfbf; }
  .tag.up { color:#f5222d; border-color:#ffccc7; background:#fff1f0; }
  .all { margin-top:12px; }
  .all summary { font-size:13px; color:#1677ff; cursor:pointer; user-select:none; }
  .all-table { width:100%; border-collapse:collapse; margin-top:8px; font-size:13px; }
  .all-table th, .all-table td { border-bottom:1px solid #f0f0f0; padding:6px 8px; text-align:left; }
  .all-table th { color:#8c8c8c; font-weight:500; background:#fafafa; }
  .all-table td.c { color:#8c8c8c; }
</style>
</head>
<body>
<div class="wrap">
  <div class="page-header">
    <h1>主线板块回溯</h1>
    <div class="sub">
      区间 ${fmtDate(dates[0])} ~ ${fmtDate(dates[dates.length - 1])}（${dates.length} 个交易日）· 数据源 lianbanSnapshot ·
      已剔除「其他」「并购重组」板块及只持续 1 天的短周期 ·
      每日主线评分 = <span class="formula">龙头高度×${W.height}</span> + <span class="formula">涨停家数×${W.count}</span> + <span class="formula">连续上榜天数×${W.streak}</span>，
      取当日最高分板块为主线；板块内个股按 最高连板×${SW.height} + 上榜天数×${SW.days} + 领涨次数×${SW.leader} 排序取前三（龙头/龙二/龙三）。
      <br>股票筛选条件（需同时满足）：① 在 ${fmtDate(EVAL_START)} ~ ${fmtDate(END)} 区间内曾出现 n 日涨幅 ≥ xx%（默认 ${GAIN_DAYS} 日 / ${GAIN_PCT}%）；② 板块内曾出现过 ≥ n 连板（默认 ${BOARD_MIN} 连板）。下方可手动调整。
    </div>
  </div>

  <div class="filters">
    <span>① 近 <input id="in-n" type="number" min="1" value="${GAIN_DAYS}"> 日涨幅 ≥ <input id="in-xx" type="number" min="0" value="${GAIN_PCT}">%</span>
    <span class="sep">｜</span>
    <span>② 板块内曾有过 ≥ <input id="in-m" type="number" min="1" value="${BOARD_MIN}"> 连板</span>
    <span class="f-hit">命中个股合计 <b id="f-total">0</b> 只</span>
  </div>

  <div class="tl-card">
    <div class="tl-head">主线时间轴（宽度 ∝ 持续交易日）</div>
    <div class="timeline">${timelineHtml}</div>
  </div>

  <div class="seg-head">主线周期明细（共 ${segments.length} 段）</div>
  <div class="cards">${cardsHtml}</div>
</div>
<script>${clientJs}</script>
</body>
</html>`;

fs.writeFileSync(OUT, html, 'utf8');

// ---------- 7. 控制台摘要 ----------
console.log(`区间 ${dates[0]}~${dates[dates.length - 1]}，共 ${dates.length} 个交易日，识别主线周期 ${segments.length} 段`);
console.log(`权重：龙头高度×${W.height} + 涨停家数×${W.count} + 连续上榜天数×${W.streak}`);
segments.forEach((s, i) => {
  console.log(`${String(i + 1).padStart(2)}. ${s.board.padEnd(6)} ${fmtDate(s.start)}~${fmtDate(s.end)}  ${String(s.dayCount).padStart(2)}日  `
    + `最高${s.maxHeight}板 涨停${s.totalCount}家  | 龙头/龙二/龙三: ${s.top.map((t) => t.name).join(' / ')}`);
});
console.log(`\n报告已生成: ${OUT}`);